/**
 * MyUnitCubeQuad
 * @constructor
 * @param scene - Reference to MyScene object
 */
class MyUnitCubeQuad extends CGFobject {
	constructor(scene) {
		super(scene);
		this.initBuffers();
		
		this.front = new MyQuad(scene);
		this.back = new MyQuad(scene);
		this.top = new MyQuad(scene);
		this.bottom = new MyQuad(scene);
		this.right = new MyQuad(scene);
		this.left = new MyQuad(scene);

		//------ Applied Material
        this.sideMaterial = new CGFappearance(scene);
        this.sideMaterial.setAmbient(0.1, 0.1, 0.1, 1);
        this.sideMaterial.setDiffuse(0.9, 0.9, 0.9, 1);
        this.sideMaterial.setSpecular(0.1, 0.1, 0.1, 1);
        this.sideMaterial.setShininess(10.0);
        this.sideMaterial.loadTexture('images/mineSide.png');
        this.sideMaterial.setTextureWrap('REPEAT', 'REPEAT');

        this.bottomMaterial = new CGFappearance(scene);
        this.bottomMaterial.setAmbient(0.1, 0.1, 0.1, 1);
        this.bottomMaterial.setDiffuse(0.9, 0.9, 0.9, 1);
        this.bottomMaterial.setSpecular(0.1, 0.1, 0.1, 1);
        this.bottomMaterial.setShininess(10.0);
        this.bottomMaterial.loadTexture('images/mineBottom.png');
        this.bottomMaterial.setTextureWrap('REPEAT', 'REPEAT');

        this.topMaterial = new CGFappearance(scene);
        this.topMaterial.setAmbient(0.1, 0.1, 0.1, 1);
        this.topMaterial.setDiffuse(0.9, 0.9, 0.9, 1);
        this.topMaterial.setSpecular(0.1, 0.1, 0.1, 1);
        this.topMaterial.setShininess(10.0);
        this.topMaterial.loadTexture('images/mineTop.png');
        this.topMaterial.setTextureWrap('REPEAT', 'REPEAT');

        //------

	}
	display() {


		this.scene.pushMatrix();
		this.sideMaterial.apply();
		this.front.display();

		this.scene.popMatrix();
		this.scene.pushMatrix();
		this.scene.rotate(Math.PI/2,0,1,0);
		this.scene.translate(0,0,1);
		this.sideMaterial.apply();
		this.right.display();

		this.scene.popMatrix();
		this.scene.pushMatrix();
		this.scene.rotate(Math.PI,0,1,0);
		this.scene.translate(-1,0,1);
		this.sideMaterial.apply();
		this.back.display();

		this.scene.popMatrix();
		this.scene.pushMatrix();
		this.scene.rotate(-Math.PI/2,0,1,0);
		this.scene.translate(-1,0,0);
		this.sideMaterial.apply();
		this.left.display();

		this.scene.popMatrix();
		this.scene.pushMatrix();
		this.scene.rotate(Math.PI/2,1,0,0);
		this.scene.translate(0,-1,0);
		this.bottomMaterial.apply();
		this.bottom.display();

		this.scene.popMatrix();
		this.scene.pushMatrix();
		this.scene.rotate(-Math.PI/2,1,0,0);
		this.scene.translate(0,0,1);
		this.topMaterial.apply();
		this.top.display();

		this.scene.popMatrix();
		

	}
}
