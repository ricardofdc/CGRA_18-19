/**
 * MyPrism
 * @constructor
 * @param scene - Reference to MyScene object
 */
class MyPrism extends CGFobject {
	constructor(scene,slices) {
		super(scene);
		this.slices = slices;
		this.initBuffers();
	}
	initBuffers() {
		this.vertices = [];
		this.indices = [];
		this.normals = [];

		var ang = 0;
		var alphaAng = 2*Math.PI/this.slices;		
		//Counter-clockwise reference of vertices
		for(var i = 0; i < this.slices; i++){

            this.vertices.push(Math.cos(ang), 0, -Math.sin(ang));
           
            this.indices.push(i, (i+1) % this.slices, i + this.slices);
            this.indices.push(i+ this.slices, (i+1) % this.slices, i);
 
            this.normals.push(Math.cos(ang), Math.cos(Math.PI/4.0), -Math.sin(ang));
            ang+=alphaAng;
        }

        for(var i = 0; i < this.slices; i++){
            this.vertices.push(Math.cos(ang), 1, -Math.sin(ang));
            this.indices.push(i + this.slices, ((i+1) % this.slices) + this.slices,(i+1) % this.slices);
            this.indices.push((i+1) % this.slices, ((i+1) % this.slices) + this.slices, i + this.slices);
            this.normals.push(Math.cos(ang), Math.cos(Math.PI/4.0), -Math.sin(ang));
            ang+=alphaAng;
        }

        
     
       
		this.primitiveType = this.scene.gl.TRIANGLES;
		this.initGLBuffers();
		
	}
	updateBuffers(complexity){
        this.slices = 3 + Math.round(9 * complexity); //complexity varies 0-1, so slices varies 3-12
		this.initBuffers();
        this.initNormalVizBuffers();
	}
}
