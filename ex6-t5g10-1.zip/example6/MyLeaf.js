/**
 * MyLeaf
 * @constructor
 * @param scene - Reference to MyScene object
 */
class MyLeaf extends CGFobject {
	constructor(scene, color) {
		super(scene);
		this.color = color;
		this.initBuffers();
	}
	initBuffers() {
		this.vertices = [
			1, -1, 0,	//0
			-1, -1, 0,	//1
			-1, 1, 0,//2
		];

		//Counter-clockwise reference of vertices
		this.indices = [
			0, 2, 1,
			1, 2, 0
		];

		
        

		this.primitiveType = this.scene.gl.TRIANGLES;
		this.initGLBuffers();
	}

	display(){
		this.color.apply();
		super.display();
	}
}

